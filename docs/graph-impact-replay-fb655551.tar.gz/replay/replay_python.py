"""Static replay of frozen merge ranges, with content-based parser memoization.

No historical code is executed. Both policies consume the same current
generator evidence. Only pure parser helpers are memoized; inventory-dependent
name resolution and closures are rebuilt for every revision.
"""
import functools
import importlib.util
import io
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import time

WT = Path(os.environ.get('GRAPH_IMPACT_WT', '/home/rob/tmp/bazel-wave2/pq/wt-impact'))
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(WT))
from tools.ci import graph_impact as new
from tools.ci import graph_impact_pq as adapter
from tools.bazel import build_files as build

spec = importlib.util.spec_from_file_location('old', HERE / 'graph_impact_old.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
repo = sys.argv[1]
root = WT if repo == 'pq' else HERE / repo
rows = json.loads((HERE / (repo + '-ranges.json')).read_text())
cache_dir = HERE / (repo + '-snapshots')
cache_dir.mkdir(exist_ok=True)

for name in ('parse', 'Bindings', 'parse_snippets', 'path_built_names',
             'sibling_names', 'module_launches', 'statement_imports', 'loader_evidence'):
    setattr(build, name, functools.lru_cache(maxsize=None)(getattr(build, name)))
build.gate_paths.references = functools.lru_cache(maxsize=None)(build.gate_paths.references)
if repo == 'tessera':
    # Use Tessera #1590's own generator source, frozen at 23909243b94b.
    # Load the stdlib-only resolver without importing production Tessera.
    import types
    import ast
    tooling = HERE / 'tessera-tooling'
    for name in ('tessera', 'tessera._dev'):
        sys.modules[name] = types.ModuleType(name)
        sys.modules[name].__path__ = []
    sd_spec = importlib.util.spec_from_file_location('tessera._dev.source_dependencies', tooling / 'source_dependencies.py')
    sd = importlib.util.module_from_spec(sd_spec)
    sys.modules[sd_spec.name] = sd
    sd_spec.loader.exec_module(sd)
    sys.path.insert(0, str(tooling))
    import evidence as te
    import graph as tg
    te.walk = functools.lru_cache(maxsize=None)(lambda tree: tuple(ast.walk(tree)))
    facts_cache = {}
    original_read = te.Evidence.read
    def read_facts(self, path):
        # Facts contain relative names/paths only. All inventory-dependent
        # resolution is invalidated whenever any file is added or removed.
        inventory = tuple(self.files)
        key = (path, (self.root / path).read_bytes(), inventory)
        if key not in facts_cache:
            facts_cache[key] = original_read(self, path)
        return facts_cache[key]
    te.Evidence.read = read_facts
    def tessera_snapshot(tree, files):
        built = tg.Graph(te.Evidence(tree, files))
        sources = {p for p in built.evidence.modules if not te.is_test_side(p)}
        tests = {t: built.closure(t) & sources for t in built.tests}
        edges = {(a, b) for a, targets in built.edges.items() for b in targets}
        edges |= {(t, tg.CONFTEST) for t in built.tests}
        loc = {p: (tree / p).read_bytes().count(b'\n') for p in sources}
        live = new.measure(tests, edges, loc, test_packages=dict.fromkeys(tests, 'tests'))
        live['edge_groups']['conftest_source'] = sorted(
            f'{tg.CONFTEST} -> {p}' for p in built.reach(tg.CONFTEST) if not te.is_test_side(p))
        live['contents'] = {t: hashlib.sha256((tree / t).read_bytes()).hexdigest() for t in tests}
        return live

def snapshot(sha):
    target = cache_dir / (sha + '.json')
    if target.exists():
        return json.loads(target.read_text())
    started = time.perf_counter()
    archive = subprocess.check_output(['git', 'archive', sha], cwd=root)
    with tempfile.TemporaryDirectory(prefix=repo + '-', dir=HERE) as directory:
        tree = Path(directory)
        files = []
        with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
            for member in tar:
                path = Path(member.name)
                if not member.isfile() or path.is_absolute() or '..' in path.parts:
                    continue
                output = tree / path
                output.parent.mkdir(parents=True, exist_ok=True)
                output.write_bytes(tar.extractfile(member).read())
                if output.name != 'BUILD.bazel' and not member.name.startswith(build.SKIPPED):
                    files.append(member.name)
        options = {}
        if repo == 'pq' and not (tree / 'tools/ci/gate_durations.json').exists():
            options['population'] = sorted(p for p in files if build.is_test(p))
        if repo == 'tessera':
            live = tessera_snapshot(tree, sorted(files))
        else:
            live = adapter.load_snapshot(tree, files=sorted(files), **options)
    target.write_text(json.dumps(live))
    print(f'{repo} graph {sha[:12]} {time.perf_counter()-started:.2f}s '
          f'{live["test_count"]} tests {live["source_files"]} sources', flush=True)
    return live

results = []
for row in reversed(rows):
    before, after = snapshot(row['base']), snapshot(row['head'])
    changed = {t for t, digest in after['contents'].items()
               if before['contents'].get(t) != digest}
    baseline = adapter.record(before) if repo == 'pq' else new.baseline_record(before)
    historical = old.compare(before, after, baseline, changed_tests=changed, record_gains=True)
    revised = new.compare(before, after, baseline, changed_tests=changed, record_gains=True)
    result = {**row, 'summary': new.summary(before, after, baseline['reach_budget']),
              'old_errors': historical, 'new_errors': revised,
              'added_edges': sorted(set(map(tuple, after['edges'])) - set(map(tuple, before['edges']))),
              'core_sha': 'fb6555514e2f43727ab73d056f82d8ad34ab64e3'}
    results.append(result)
    (HERE / (repo + '-results.json')).write_text(json.dumps(results, indent=2))
    print(f'{repo} #{row["pr"]}: old={bool(historical)} new={bool(revised)} '
          f'{result["summary"]}', flush=True)
print(json.dumps({'repo': repo, 'count': len(results),
                  'old_fail': sum(bool(r['old_errors']) for r in results),
                  'new_fail': sum(bool(r['new_errors']) for r in results),
                  'new_fail_prs': [r['pr'] for r in results if r['new_errors']]}), flush=True)
