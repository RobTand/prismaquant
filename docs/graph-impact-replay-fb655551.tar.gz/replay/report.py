"""Publish all failure reasons and exact graph diffs from the frozen ranges."""
import collections
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
CORE = 'fb6555514e2f43727ab73d056f82d8ad34ab64e3'

def reason(error):
    if error.startswith('new '):
        return error.split(':', 1)[0]
    if error.startswith('SCC grew'):
        return error.split(':', 1)[0]
    if error.startswith('existing source'):
        return 'existing source fanout grew'
    if error.startswith('existing test'):
        return 'existing test reach grew'
    if 'exceeds budget' in error:
        return error.split(';', 1)[0]
    return error.split(';', 1)[0]

lines = ['# Historical graph-impact replay', '', f'Frozen revised core: `{CORE}`.', '',
         'The old core is the pre-review `72af52b5` implementation. Each policy uses',
         'the same base/head graph and a baseline measured at that range’s base.',
         'Changed test bodies are detected by content hashes. Baseline gain recording',
         'is enabled so this replay judges regressions rather than baseline maintenance.', '',
         'PrismaQuant uses the current generator’s evidence and its hosted gate population.',
         'Revisions predating the hosted selector use all test files. Tessera uses its own',
         '#1590 generator evidence at `23909243b94bb308dc19c80c9f91567412aaa855`,',
         'including `src/tessera` module resolution and its conftest closure rule.',
         'Historical application code is parsed, never executed. Pure parser work is',
         'memoized; Tessera facts are invalidated when source bytes or file inventory change.', '',
         'All base/head SHAs, full diagnostics under both policies, and every added edge',
         'are retained in the adjacent `pq-results.json` and `tessera-results.json`.',
         'The frozen 30 first-parent merge ranges are in the `*-ranges.json` manifests.',
         'TL3 is excluded from this worker’s replay by the lead’s explicit correction.', '']

totals = {}
for repo in ('pq', 'tessera'):
    rows = json.loads((HERE / (repo + '-results.json')).read_text())
    assert len(rows) == 30
    counts = {'old_fail': sum(bool(r['old_errors']) for r in rows),
              'new_fail': sum(bool(r['new_errors']) for r in rows),
              'new_fail_prs': [r['pr'] for r in rows if r['new_errors']]}
    totals[repo] = counts
    lines += [f'## {repo}', '', f'Old failures: {counts["old_fail"]}/30. Revised failures: {counts["new_fail"]}/30.', '',
              '| PR | Old failure reasons | Revised failure reasons |', '|---|---|---|']
    for row in rows:
        groups = []
        for key in ('old_errors', 'new_errors'):
            counts_by_reason = collections.Counter(reason(e) for e in row[key])
            groups.append('; '.join(f'{label} ×{count}' if count > 1 else label
                                    for label, count in counts_by_reason.items()) or 'pass')
        lines.append(f'| #{row["pr"]} | {groups[0]} | {groups[1]} |')
    lines += ['', '### Revised failures and added edges', '']
    for row in rows:
        if not row['new_errors']:
            continue
        causes = set(re.findall(r'([\w./:@+\-]+) -> ([\w./:@+\-]+)', '\n'.join(row['new_errors'])))
        actual = set(map(tuple, row['added_edges']))
        selected = sorted(causes & actual) or sorted(actual)
        details = {'pr': row['pr'], 'base': row['base'], 'head': row['head'],
                   'failures': row['new_errors'], 'added_edges': row['added_edges'],
                   'diagnostic_edges': sorted(causes), 'core': CORE}
        (HERE / f'{repo}-{row["pr"]}-failure.json').write_text(json.dumps(details, indent=2))
        lines += [f'#### #{row["pr"]}', '',
                  '; '.join(dict.fromkeys(reason(e) for e in row['new_errors'])) + '.', '',
                  f'{len(selected)} added graph edges named by diagnostics; '
                  f'{len(actual)} total added graph edges. Full details: `{repo}-{row["pr"]}-failure.json`.', '',
                  '```text', *[f'{a} -> {b}' for a, b in selected], '```', '']

(HERE / 'replay-report.md').write_text('\n'.join(lines))
(HERE / 'totals.json').write_text(json.dumps(totals, indent=2))
print(json.dumps(totals))
