Replay evidence for frozen core fb6555514e2f43727ab73d056f82d8ad34ab64e3.

Read replay/replay-report.md for every old/new failure reason and exact causal added edges.
The *-results.json files also retain every added graph edge, including unrelated ones.

Reproduce static analysis without running tests:
1. Clone RobTand/prismaquant into a checkout and select 0b4343d68c03dcb482ae5f137c5aefbb93223a2e.
2. Clone RobTand/tessera into replay/tessera beside the extracted replay script.
3. Export GRAPH_IMPACT_WT to the absolute PrismaQuant checkout path.
4. Run python3 replay/replay_python.py pq and python3 replay/replay_python.py tessera.
5. Run python3 replay/report.py.
Historical code is parsed, never executed. Python 3.12 or newer and stdlib suffice.
The current fixed generator is deliberately used at every historical revision.
The manifests freeze 30 first-parent merged PR ranges per repo, rather than moving branch heads.
TL3 replay belongs to the coordinator's worker and is not duplicated here.

Native proof: native/blame.mmd comes from released bazel-diff v70.0.2 on a real tiny Bazel workspace.
Raw deps omit rule-to-source edges; native/supplemented-deps.json adds edges from the streamed query.
The CLI adapter builds that supplementation in a temporary file and preserves the raw export.

Development tests were run on BuildBuddy, never directly on a fleet host.
Post-security-rule remote steps unset BUILDBUDDY_API_KEY and scan artifacts before upload.
All assembled inputs in this bundle were byte-scanned locally for the credential before packaging.
