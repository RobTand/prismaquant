"""Create a local throwaway commit with source-import regressions; no checkout."""
import json
import os
from pathlib import Path
import subprocess
from tools.ci import graph_impact_pq as pq
root=Path.cwd()
notes=Path('/home/rob/tmp/bazel-wave2/pq/notes/graphimpact')
before=json.loads((notes/'current-live.json').read_text())
component=set(before['scc_members'])
back=next((a,b) for a,b in before['edges'] if a in component and b not in component and b.startswith('prismaquant/') and b.endswith('.py'))
source,target=back
print('cycle back import',target,'->',source)
env={**os.environ,'GIT_INDEX_FILE':str(notes/'bad-package.index')}
subprocess.run(['git','read-tree','HEAD'],env=env,check=True)
def put(path,text):
    blob=subprocess.check_output(['git','hash-object','-w','--stdin'],input=text.encode()).decode().strip()
    subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,path],env=env,check=True)
imports=[]
for path in before['loc']:
    parts=path.removesuffix('.py').split('/')
    if parts[-1]=='__init__':parts=parts[:-1]
    if all(part.isidentifier() for part in parts):imports.append('import '+'.'.join(parts))
put('tests/conftest.py',(root/'tests/conftest.py').read_text()+'\n'+'\n'.join(imports)+'\n')
put('tests/graphimpact_new/test_bad.py','from tests.test_graph_impact import measure\ndef test_bad():\n    assert True\n')
module=source.removesuffix('.py').removesuffix('/__init__').replace('/','.')
put(target,(root/target).read_text()+'\nimport '+module+'\n')
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip()
sha=subprocess.check_output(['git','commit-tree',tree,'-p','HEAD'],input='Synthetic graph impact rejection evidence\n',text=True).strip()
subprocess.run(['git','branch','-f','prismaquant-3215-graphimpact-bad-package',sha],check=True)
(notes/'bad-package.json').write_text(json.dumps({'sha':sha,'target':target,'source':source}))
print('throwaway branch',sha)
